import subprocess as sp
import config


def get_tool_path():
    tool_path_encoded = sp.check_output("pwd", shell=True)
    return tool_path_encoded.decode('utf-8').rstrip() + "/"

def send_mail(zip_result_file,recp):
     tool_path = get_tool_path()
     file_path = tool_path + zip_result_file+".zip"
     etext = "Hello, Please find the attached html files for the Metadata table Differences in given Databases. Source: "+ config.source_db["host"]+" and Target: "+ config.target_db["host"]
     cmd = 'echo '+ etext +' | mailx -r noreply-metadatatool@amdocs.com -a '+ file_path + ' -s "DB Metadata Differences" '+recp
     sp.Popen(cmd, shell=True)
     print("Email Sent Successfully")