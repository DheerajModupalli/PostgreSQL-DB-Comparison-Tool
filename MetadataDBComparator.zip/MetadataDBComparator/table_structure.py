tables = {
    "adj1_attributes_id_map": {
        "custom_col": [],
        "comparePrimaryKey": False,
        "compareAllColumns": True,
        "columnsToExclude": ["sys_creation_date", "sys_update_date"],
        "param_value": []
    },

    "adj1_es_rate_policies_cfg": {
        "custom_col": [],
        "comparePrimaryKey": False,
        "compareAllColumns": True,
        "columnsToExclude": ["sys_creation_date", "sys_update_date", ],
        "param_value": []
    },

    "adj1_id_mapping": {
        "custom_col": [],
        "comparePrimaryKey": False,
        "compareAllColumns": True,
        "columnsToExclude": ["sys_creation_date", "sys_update_date", ],
        "param_value": []
    },

    "adj1_metadata": {
        "custom_col": [],
        "comparePrimaryKey": True,
        "compareAllColumns": False,
        "columnsToExclude": ['sys_creation_date', 'sys_update_date'],
        "param_value": []
    },

    "adj1_metadata_attributes": {
        "custom_col": [],
        "comparePrimaryKey": False,
        "compareAllColumns": True,
        "columnsToExclude": ['sys_creation_date', 'sys_update_date'],
        "param_value": []
    },

    "adj1_mpr_files": {
        "custom_col": [],
        "comparePrimaryKey": False,
        "compareAllColumns": True,
        "columnsToExclude": ['sys_creation_date', 'sys_update_date'], "param_value": []
    },

    "adj1_mpr_packages": {
        "custom_col": [],
        "comparePrimaryKey": False,
        "compareAllColumns": True,
        "columnsToExclude": ['sys_creation_date', 'sys_update_date'],
        "param_value": []
    },

    "adj1_protocol_errs_cfg": {
        "custom_col": [],
        "comparePrimaryKey": False,
        "compareAllColumns": True,
        "columnsToExclude": ['sys_creation_date', 'sys_update_date'],
        "param_value": []
    },

    "adj1_release_info": {
        "custom_col": [],
        "comparePrimaryKey": False,
        "compareAllColumns": True,
        "columnsToExclude": ["sys_creation_date", "sys_update_date"],
        "param_value": []
    },

    "adj1_release_metadata_lnk": {
        "custom_col": [],
        "comparePrimaryKey": False,
        "compareAllColumns": True,
        "columnsToExclude": ['sys_creation_date', 'sys_update_date'], "param_value": []
    },

    "adj1_subscr_attributes": {
        "custom_col": [],
        "comparePrimaryKey": False,
        "compareAllColumns": True,
        "columnsToExclude": ['sys_creation_date', 'sys_update_date'], "param_value": []
    },

    "aicg_log_messages": {
        "custom_col": [],
        "comparePrimaryKey": False,
        "compareAllColumns": True,
        "columnsToExclude": ['sys_creation_date', 'sys_update_date'], "param_value": []
    },

    "ape1_accum_map": {
        "custom_col": [],
        "comparePrimaryKey": False,
        "compareAllColumns": True,
        "columnsToExclude": ['sys_creation_date', 'sys_update_date'],
        "param_value": []
    },

    "ape1_accum_to_ext_rec": {
        "custom_col": [],
        "comparePrimaryKey": False,
        "compareAllColumns": True,
        "columnsToExclude": ['sys_creation_date', 'sys_update_date'],
        "param_value": []
    },

    "ape1_rated_event_map": {
        "custom_col": [],
        "comparePrimaryKey": False,
        "compareAllColumns": True,
        "columnsToExclude": ["sys_creation_date", "sys_update_date"],
        "param_value": []
    },

    "ape1_uoms": {
        "custom_col": [],
        "comparePrimaryKey": False,
        "compareAllColumns": True,
        "columnsToExclude": ['sys_creation_date', 'sys_update_date'],
        "param_value": []
    },

    "pc1_mrkt_param": {
        "custom_col": ["PARAMETER_NAME", "BUSINESS_ENTITY"],
        "comparePrimaryKey": False,
        "compareAllColumns": False,
        "columnsToExclude": [],
        "param_value": ["parameter_values"]
    },
}
## 1. if custom_col is defined take it as the list to compare along with param value(if param_value not empty)
# 2. if pk is set to true compare pk with param_value(if param_value not empty)
# 3. if allcolumn set to true then subtract excluding from it and then use it.
#   "Table Name" : ( ["Primary key 1","Primary key 2","Primary key 3",........] , ["Param 1","Param 2","Param 3",.......] )
