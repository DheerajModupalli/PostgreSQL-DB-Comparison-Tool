import config
import db_util
import table_structure
import re

result_dir_name = 'TableDetails_' + config.source_db["host"] + '_' + config.target_db["host"]

# this is used for creating html with table details other than DB STATS.html
def generate_table(result_dict,table_name,column_names):

    #Header
    html_table_str = "<head>\n<style>\nth,td{border: 1px solid black;padding: 15px;}\n</style></head>\n"
    html_table_str += "<table border>\n"


    colval = len(column_names)

    html_table_str += "<tr><th colspan="+str(colval)+">{}</th></tr>\n".format(table_name)
    html_table_str += "<tr><th colspan=" + str(colval) +">ONLY IN SOURCE - " + config.source_db["name"] +" ("+ config.source_db["host"]+")"  + "</th></tr>\n"

    html_table_str += "<tr>"
    for item in (column_names):
        html_table_str += "<td>{}</td>\n".format(item)
    html_table_str += "</tr>"

    # html_table_str += "<tr><td>{}</td></tr>\n".format(str(table_structure.tables[table_name][0]))

    for value in result_dict[table_name][0][1]:
        row = "<tr><td>{}</td></tr>\n".format(re.sub("~", "</td><td>", value))
        html_table_str+=row

    html_table_str += "<tr><td bgcolor='#FFFFFF' style='line-height:10px;' colspan="+str(colval)+">&nbsp;</td></tr>\n"

    html_table_str += "<tr><th colspan=" + str(colval) +">ONLY IN TARGET - " + config.target_db["name"] +" ("+ config.target_db["host"]+")"  + "</td></th>\n"

    html_table_str += "<tr>"
    for item in (column_names):
        html_table_str += "<td>{}</td>\n".format(item)
    html_table_str += "</tr>"
    # html_table_str += "<tr><td>{}</td></tr>\n".format(str(table_structure.tables[table_name][0]))

    for value in result_dict[table_name][1][1]:
        row = "<tr><td>{}</td></tr>\n".format(re.sub("~", "</td><td>", value))
        html_table_str+=row

    html_table_str += "<tr><td bgcolor='#FFFFFF' style='line-height:10px;' colspan="+str(colval)+">&nbsp;</td></tr>\n"

    html_table_str += "<tr><th colspan="+str(colval)+">COMMON PK WITH DIFF PARAM VALUE</th></tr>\n"

    html_table_str += "<tr>"
    for item in (column_names):
        html_table_str += "<td>{}</td>\n".format(item)
    html_table_str += "</tr>"
    # html_table_str += "<tr><td>{}</td></tr>\n".format(str(table_structure.tables[table_name][0]))

    for value in result_dict[table_name][2][1]:
        row = "<tr><td>{}</td></tr>\n".format(re.sub("~", "</td><td>", value))
        html_table_str += row

    html_table_str += "</table>"


    with open('./'+result_dir_name+'/'+table_name+'_details.html', 'w') as f:
        f.write(html_table_str)

