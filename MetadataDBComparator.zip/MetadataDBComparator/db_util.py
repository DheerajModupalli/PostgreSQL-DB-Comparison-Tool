import psycopg2

from table_structure import tables
import config


def make_db_connection(db_details):
    connection = psycopg2.connect(database=db_details["database"],
                                  user=db_details["user"],
                                  host=db_details["host"],
                                  password=db_details["password"],
                                  port=db_details["port"])
    return connection


def fetch_column_combination(table_name, cursor_source, conn_source, cursor_target, conn_target):
    if len(tables[table_name]["custom_col"]) > 0:
        combined_columns_source, column_names_source = fetch_custom_columns(table_name, cursor_source,
                                                                            conn_source)
        combined_columns_target, column_names_target = fetch_custom_columns(table_name, cursor_target,
                                                                            conn_target)
        return combined_columns_source, combined_columns_target, column_names_source
    if tables[table_name]["comparePrimaryKey"]:
        combined_columns_source, column_names_source = fetch_pk_combination(table_name, cursor_source, conn_source)
        combined_columns_target, column_names_target = fetch_pk_combination(table_name, cursor_target, conn_target)
        return combined_columns_source, combined_columns_target, column_names_source
    if tables[table_name]["compareAllColumns"]:
        combined_columns_source, column_names_source = fetch_columns_excluding_some(table_name, cursor_source,
                                                                                    conn_source)
        combined_columns_target, column_names_target = fetch_columns_excluding_some(table_name, cursor_target,
                                                                                    conn_target)
        return combined_columns_source, combined_columns_target, column_names_source


def fetch_columns_excluding_some(table_name, cursor, connection):
    cursor.execute("SELECT column_name FROM information_schema.columns WHERE table_name = '" + table_name + "'")
    # Fetch all the rows
    rows = cursor.fetchall()
    # Store the column names in a list
    column_names = [row[0] for row in rows]
    exclude_column = tables[table_name]["columnsToExclude"]
    column_names.sort()
    columns_to_compare = [item for item in column_names if item not in exclude_column]
    query_str = ("SELECT CONCAT(" + "::TEXT,'~',".join(
        columns_to_compare) + "::TEXT" + ") AS COMBINED_PK FROM " + table_name + ";")
    cursor.execute(query_str)
    combined_list = [row[0] for row in cursor.fetchall()]
    connection.commit()
    return combined_list, columns_to_compare


def fetch_pk_combination(table_name, cursor, connection):
    # query_str = "SELECT " + ",".join(tables[table_name][0]) + " FROM " + table_name + ";"
    cursor.execute(
        "SELECT column_name FROM information_schema.key_column_usage WHERE table_name = '" + table_name + "' AND constraint_name IN ( SELECT constraint_name FROM information_schema.table_constraints WHERE table_name ='" + table_name + "' AND constraint_type = 'PRIMARY KEY');")
    # Fetch all the rows
    prows = cursor.fetchall()
    # Store the column names in a list
    primary_col = [prow[0] for prow in prows]
    primary_col.sort()
    query_str = ("SELECT CONCAT(" + "::TEXT,'~',".join(
        primary_col) + "::TEXT" + ") AS COMBINED_PK FROM " + table_name + ";")
    cursor.execute(query_str)
    pk_list = [row[0] for row in cursor.fetchall()]
    connection.commit()
    return pk_list, primary_col


def fetch_custom_columns(table_name, cursor, connection):
    query_str = ("SELECT CONCAT(" + "::TEXT,'~',".join(
        tables[table_name]["custom_col"]) + "::TEXT" + ") AS COMBINED_COL FROM " + table_name + ";")
    cursor.execute(query_str)
    combined_list = [row[0] for row in cursor.fetchall()]
    combined_list.sort()
    connection.commit()
    return combined_list, tables[table_name]["custom_col"]


def print_output(result_dict):
    print(
        "--------------------------------------------------------------------------------------------------------------------------------")
    print("{:<40} {:35} {:<35} {:<20}".format('Table', "Only in Source - " + config.source_db["host"],
                                              "Only in Target - " + config.target_db["host"], 'Diff rows'))
    print(
        "--------------------------------------------------------------------------------------------------------------------------------")
    for k, v in result_dict.items():
        only_source, only_target, diff = v
        print("{:<41} {:<36} {:<35} {:<20}\n".format(k, only_source[0], only_target[0], diff[0]))
    print(
        "--------------------------------------------------------------------------------------------------------------------------------")

# "select column_name from information_schema.columns where table_schema = 'xpidbo1' and table_name='adj1_att'"
