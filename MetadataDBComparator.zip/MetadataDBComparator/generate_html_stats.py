import config
import generate_html_table_details


def generate_table(result_dict):
    html_table = "<table style='border:1px solid black; border-collapse: collapse;'>\n"

    # Add column headers
    html_table += "<tr><th style='border:1px solid black; padding:10px;'>Table Name</th><th style='border:1px solid black; padding:10px;'>Only in Source - " + config.source_db["name"] +" ("+ config.source_db["host"]+")" +"</th><th style='border:1px solid black; padding:10px;'>Only in Target - " + config.target_db["name"] +" ("+ config.target_db["host"]+")" + "</th><th style='border:1px solid black; padding:10px;'>Different Rows</th></tr>\n"
    # html_table += "<tr><th style='border:1px solid black; padding:10px;'>Table Name</th><th style='border:1px solid black; padding:10px;'>Only in </th><th style='border:1px solid black; padding:10px;'>Only in </th><th style='border:1px solid black; padding:10px;'>Different Rows</th><th style='border:1px solid black; padding:10px;'>Details</th></tr>\n"


    # Add row data
    for key, values in result_dict.items():
        html_table += "<tr><td style='border:1px solid black; padding:10px;'><a href=./"+key+"_details.html>{}</td>".format(key)
        value1 =  result_dict[key][0][0]
        if value1 == 0:
          row = "<td style='border:1px solid black; padding:10px;'><font color='black'>{}</font></td>\n".format(value1) #added href
        else:
          row = "<td style='border:1px solid black; padding:10px;'><font color='red'>{}</font></td>\n".format(value1)
        html_table += row
        
        value2 = result_dict[key][1][0]
        if value2 == 0:
          row = "<td style='border:1px solid black; padding:10px;'><font color='black'>{}</font></td>\n".format(value2)
        else:
          row = "<td style='border:1px solid black; padding:10px;'><font color='green'>{}</font></td>\n".format(value2)
        html_table += row
        
        value3 = result_dict[key][2][0]
        if value3 == 0:
          row = "<td style='border:1px solid black; padding:10px;'><font color='black'>{}</font></td>\n".format(value3)
        else:
          row = "<td style='border:1px solid black; padding:10px;'><font color='red'>{}</font></td>\n".format(value3)
        html_table += row

        # html_table += "<td style='border:1px solid black; padding:10px;'><button onclick='location.href='details.html';' type='button'>view</button></td"
        html_table += "</tr>\n"

    # End the HTML table
    html_table += "</table>"

    # ./TableDetails_10.238.169.37_10.238.160.134/DB STST.html
    with open("./" + generate_html_table_details.result_dir_name + '/MetadataCompareStats.html', 'w') as f:
        f.write(html_table)

   
