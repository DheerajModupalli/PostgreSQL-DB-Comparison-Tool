from table_structure import tables
import table_structure


def fetch_paramval_map(table_name, cursor, connection):
    column_names = []
    query_str = ""
    if len(table_structure.tables[table_name]["custom_col"]) > 0:
        query_str = ("SELECT CONCAT(" + "::TEXT,'~',".join(tables[table_name]["custom_col"]) + "::TEXT" + ") AS COMBINED_PK " + ", CONCAT(" + "::TEXT,'~',".join(tables[table_name]["param_value"]) + "::TEXT" + ") AS COMBINED_PM " + " FROM " + table_name + ";")
        column_names=table_structure.tables[table_name]["custom_col"]

    elif table_structure.tables[table_name]["comparePrimaryKey"]:
        cursor.execute("SELECT column_name FROM information_schema.key_column_usage WHERE table_name = '" + table_name + "' AND constraint_name IN ( SELECT constraint_name FROM information_schema.table_constraints WHERE table_name ='" + table_name + "' AND constraint_type = 'PRIMARY KEY');")
        prows = cursor.fetchall()
        column_names = [prow[0] for prow in prows]
        column_names.sort()
        query_str = ("SELECT CONCAT(" + "::TEXT,'~',".join(column_names) + "::TEXT" + ") AS COMBINED_PK " + ", CONCAT(" + "::TEXT,'~',".join(tables[table_name]["param_value"]) + "::TEXT" + ") AS COMBINED_PM " + " FROM " + table_name + ";")

    cursor.execute(query_str)
    connection.commit()
    paramval_map = {row[0]: row[1] for row in cursor.fetchall()}
    return paramval_map, column_names


def compare_param_value(table_name, cursor_source, cursor_target, connection_source, connection_target):
    source_paramval_map,column_source = fetch_paramval_map(table_name, cursor_source, connection_source)
    target_paramval_map,column_tar = fetch_paramval_map(table_name, cursor_target, connection_target)
    common_columns_set = set(source_paramval_map.keys()).intersection(set(target_paramval_map.keys()))
    combined_paramval_map = dict.fromkeys(common_columns_set, [])
    diff_pks = []
    diff_count = 0
    for common_pk in combined_paramval_map.keys():
        is_param_val_same = (type(source_paramval_map[common_pk]) is type(target_paramval_map[common_pk]) and
                             source_paramval_map[common_pk] == target_paramval_map[common_pk])
        if not is_param_val_same:
            diff_count += 1
            diff_pks.append(common_pk)
        combined_paramval_map[common_pk] = [source_paramval_map[common_pk], target_paramval_map[common_pk],
                                               is_param_val_same]

    return [(len(list(set(source_paramval_map.keys()) - set(target_paramval_map.keys()))),
             list(set(source_paramval_map.keys()) - set(target_paramval_map.keys()))),
            (len(list(set(target_paramval_map.keys()) - set(source_paramval_map.keys()))),
             list(set(target_paramval_map.keys()) - set(source_paramval_map.keys()))),
            (diff_count, diff_pks)],column_source
