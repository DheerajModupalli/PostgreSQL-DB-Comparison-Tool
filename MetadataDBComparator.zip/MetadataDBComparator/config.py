source_db = {
    "name" : "ENV9",
    "database" : "paaspg",
    "user" : "env9o",
    "host" : "10.245.80.64",
    "password" : "env9o",
    "port" : 5432
}
target_db = {
    "name" : "ENV6",
    "database" : "paaspg",
    "user" : "env6o",
    "host" : "10.245.80.89",
    "password" : "env6o",
    "port" : 5432
}




