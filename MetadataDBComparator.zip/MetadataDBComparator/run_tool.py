import os
import shutil
import sys
import table_structure
from config import *
import generate_html_table_details
import generate_html_stats
from compare_param_value import compare_param_value
import db_util


if len(sys.argv) == 1:
    print("No Mail id Provided.")
else:
    recp = sys.argv[1]

# make source and target DB connections
conn_source = db_util.make_db_connection(source_db)
conn_target = db_util.make_db_connection(target_db)
cursor_source = conn_source.cursor()
cursor_target = conn_target.cursor()
result_dict = {}

if not os.path.exists("./" + generate_html_table_details.result_dir_name):
    os.mkdir("./" + generate_html_table_details.result_dir_name)

for table_name in table_structure.tables:
    if len(table_structure.tables[table_name]["param_value"]) > 0:
        param_val_diff_res, column_names_source = compare_param_value(table_name, cursor_source, cursor_target, conn_source, conn_target)
        result_dict[table_name] = param_val_diff_res
        generate_html_table_details.generate_table(result_dict, table_name, column_names_source)
    else:
        combined_columns_source, combined_columns_target, column_names_source = db_util.fetch_column_combination(table_name, cursor_source, conn_source, cursor_target, conn_target)
        result_dict[table_name] = [(len(list(set(combined_columns_source) - set(combined_columns_target))),
                                    list(set(combined_columns_source) - set(combined_columns_target))),
                                   (len(list(set(combined_columns_target) - set(combined_columns_source))),
                                    list(set(combined_columns_target) - set(combined_columns_source))),
                                   (0, []), ]
        '''
                     result dict format = {
                                                       table_name: [
                                                           (only source count, [only source elements]),
                                                           (only target count, [only target elements]),
                                                           (diff count, [diff elements])
                                                       ]
                                           }
        '''
        generate_html_table_details.generate_table(result_dict, table_name, column_names_source)


conn_source.close()
conn_target.close()
db_util.print_output(result_dict)

with open("isFirstRun.txt", "r") as file:
    if "true" in file.read():
        print('Please type "yes" and when prompted(ECDSA key fingerprint)')
    else:
        print("")
        
with open("isFirstRun.txt", "w") as file:
    file.write("false")


generate_html_stats.generate_table(result_dict)

shutil.make_archive(generate_html_table_details.result_dir_name, "zip", "./" + generate_html_table_details.result_dir_name)

# if len(sys.argv) == 2:
#   try:
#       mailer.send_mail(generate_html_table_details.result_dir_name,recp)
#   except Exception:
#       print("No Mail Sent")
#
# subprocess.Popen(f"ssh xpiwrk1@10.238.169.36 python MetadataDBComparator_Count/run_count.py", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()






